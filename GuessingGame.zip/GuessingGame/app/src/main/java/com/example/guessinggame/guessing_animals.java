package com.example.guessinggame;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Random;

public class guessing_animals extends AppCompatActivity {
    private Button b_answer1;
    private Button b_answer2;
    private Button b_answer3;
    private Button b_answer4;
    private TextView score;
    private TextView timer;

    private ImageView animal;

    private List<AnimalItem> list;

    private Random r;

    private static final long COUNTDOWN_IN_MILLIS= 25000;
    private CountDownTimer mCountDownTimer;
    private boolean mTimerRunning; /* Tell us if the timer is running or not */
    private long mTimeLeftInMillis = COUNTDOWN_IN_MILLIS;

    private int turn = 1;
    private int current_score = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_guessing_animals);

        if(savedInstanceState != null){
            current_score = savedInstanceState.getInt("key_current_score",0);
            mTimeLeftInMillis = savedInstanceState.getLong("key_time");
            score.setText(String.format("Score: %d", current_score));
        }

        animal = findViewById(R.id.Animal);
        b_answer1 = findViewById(R.id.b_answer1);
        b_answer2 = findViewById(R.id.b_answer2);
        b_answer3 = findViewById(R.id.b_answer3);
        b_answer4 = findViewById(R.id.b_answer4);
        score = findViewById(R.id.score);
        timer = findViewById(R.id.timer);

        r = new Random();

        /* adds all animal images and names to the list by creating new animal items */
        list = new ArrayList<>();
        for (int i = 0; i < new Data().answers.length; i++) {
            list.add(new AnimalItem(new Data().answers[i], new Data().animals[i]));
        }

        /* shuffle the animals: get our animals in a random order */
        Collections.shuffle(list);

        newQuestion(turn);

        startTimer();

        b_answer1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                /* Check if the answer is true: */
                if (b_answer1.getText().toString().equals(getString(list.get(turn - 1).getName()))) {
                    Toast.makeText(guessing_animals.this, "Correct!", Toast.LENGTH_SHORT).show();
                    current_score += 2;
                    score.setText(String.format("Score: %d", current_score));
                    /* Check if it's the last question: */
                    if (turn < list.size()) {
                        turn++;
                        newQuestion(turn);
                    } else {
                        Toast.makeText(guessing_animals.this, "YOU FINISHED!", Toast.LENGTH_SHORT).show();
                        Send();
                    }
                } else {
                    Toast.makeText(guessing_animals.this, "Wrong!", Toast.LENGTH_SHORT).show();
                    if (current_score > 0){
                        current_score -= 1;
                        score.setText(String.format("Score: %d", current_score));
                    }
                    if (turn < list.size()) {
                        turn++;
                        newQuestion(turn);
                    } else {
                        /* When last question is answered, send score to MainActivity2: */
                        Toast.makeText(guessing_animals.this, "YOU FINISHED!", Toast.LENGTH_SHORT).show();
                        Send();
                    }
                }
            }
        });

        b_answer2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (b_answer2.getText().toString().equals(getString(list.get(turn - 1).getName()))) {
                    Toast.makeText(guessing_animals.this, "Correct!", Toast.LENGTH_SHORT).show();
                    current_score += 2;
                    score.setText(String.format("Score: %d", current_score));
                    if (turn < list.size()) {
                        turn++;
                        newQuestion(turn);
                    } else {
                        Toast.makeText(guessing_animals.this, "YOU FINISHED!", Toast.LENGTH_SHORT).show();
                        Send();
                    }
                } else {
                    Toast.makeText(guessing_animals.this, "Wrong!", Toast.LENGTH_SHORT).show();
                    if (current_score > 0){
                        current_score -= 1;
                        score.setText(String.format("Score: %d", current_score));
                    }
                    if (turn < list.size()) {
                        turn++;
                        newQuestion(turn);
                    } else {
                        Toast.makeText(guessing_animals.this, "YOU FINISHED!", Toast.LENGTH_SHORT).show();
                        Send();
                    }
                }
            }
        });
        b_answer3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (b_answer3.getText().toString().equals(getString(list.get(turn - 1).getName()))) {
                    Toast.makeText(guessing_animals.this, "Correct!", Toast.LENGTH_SHORT).show();
                    current_score += 2;
                    score.setText(String.format("Score: %d", current_score));
                    if (turn < list.size()) {
                        turn++;
                        newQuestion(turn);
                    } else {
                        Toast.makeText(guessing_animals.this, "YOU FINISHED!", Toast.LENGTH_SHORT).show();
                        Send();
                    }
                } else {
                    Toast.makeText(guessing_animals.this, "Wrong!", Toast.LENGTH_SHORT).show();
                    if (current_score > 0){
                        current_score -= 1;
                        score.setText(String.format("Score: %d", current_score));
                    }
                    if (turn < list.size()) {
                        turn++;
                        newQuestion(turn);
                    } else {
                        Toast.makeText(guessing_animals.this, "YOU FINISHED!", Toast.LENGTH_SHORT).show();
                        Send();
                    }
                }
            }
        });
        b_answer4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (b_answer4.getText().toString().equals(getString(list.get(turn - 1).getName()))) {
                    Toast.makeText(guessing_animals.this, "Correct!", Toast.LENGTH_SHORT).show();
                    current_score += 2;
                    score.setText(String.format("Score: %d", current_score));
                    if (turn < list.size()) {
                        turn++;
                        newQuestion(turn);
                    } else {
                        Toast.makeText(guessing_animals.this, "YOU FINISHED!", Toast.LENGTH_SHORT).show();
                        Send();
                    }
                } else {
                    Toast.makeText(guessing_animals.this, "Wrong!", Toast.LENGTH_SHORT).show();
                    if (current_score > 0){
                        current_score -= 1;
                        score.setText(String.format("Score: %d", current_score));
                    }
                    if (turn < list.size()) {
                        turn++;
                        newQuestion(turn);
                    } else {
                        Toast.makeText(guessing_animals.this, "YOU FINISHED!", Toast.LENGTH_SHORT).show();
                        Send();
                    }
                }
            }
        });
    }
    /* function that randomizes the answer buttons and images*/
    private void newQuestion(int number) {
        //set the image
        animal.setImageResource(list.get(number - 1).getImage());
        int correct_answer = r.nextInt(4) + 1;

        int firstButton = number - 1;
        int secondButton;
        int thirdButton;
        int forthButton;

        switch (correct_answer) {
            case 1:
                b_answer1.setText(list.get(firstButton).getName());
                do {
                    secondButton = r.nextInt(list.size());
                } while (secondButton == firstButton);
                do {
                    thirdButton = r.nextInt(list.size());
                } while (thirdButton == firstButton || thirdButton == secondButton);
                do {
                    forthButton = r.nextInt(list.size());
                } while (forthButton == firstButton || forthButton == secondButton || forthButton == thirdButton);

                b_answer2.setText(list.get(secondButton).getName());
                b_answer3.setText(list.get(thirdButton).getName());
                b_answer4.setText(list.get(forthButton).getName());

                break;
            case 2:
                b_answer2.setText(list.get(firstButton).getName());
                do {
                    secondButton = r.nextInt(list.size());
                } while (secondButton == firstButton);
                do {
                    thirdButton = r.nextInt(list.size());
                } while (thirdButton == firstButton || thirdButton == secondButton);
                do {
                    forthButton = r.nextInt(list.size());
                } while (forthButton == firstButton || forthButton == secondButton || forthButton == thirdButton);

                b_answer1.setText(list.get(secondButton).getName());
                b_answer3.setText(list.get(thirdButton).getName());
                b_answer4.setText(list.get(forthButton).getName());

                break;
            case 3:
                b_answer3.setText(list.get(firstButton).getName());
                do {
                    secondButton = r.nextInt(list.size());
                } while (secondButton == firstButton);
                do {
                    thirdButton = r.nextInt(list.size());
                } while (thirdButton == firstButton || thirdButton == secondButton);
                do {
                    forthButton = r.nextInt(list.size());
                } while (forthButton == firstButton || forthButton == secondButton || forthButton == thirdButton);

                b_answer2.setText(list.get(secondButton).getName());
                b_answer1.setText(list.get(thirdButton).getName());
                b_answer4.setText(list.get(forthButton).getName());

                break;
            case 4:
                b_answer4.setText(list.get(firstButton).getName());
                do {
                    secondButton = r.nextInt(list.size());
                } while (secondButton == firstButton);
                do {
                    thirdButton = r.nextInt(list.size());
                } while (thirdButton == firstButton || thirdButton == secondButton);
                do {
                    forthButton = r.nextInt(list.size());
                } while (forthButton == firstButton || forthButton == secondButton || forthButton == thirdButton);

                b_answer2.setText(list.get(secondButton).getName());
                b_answer3.setText(list.get(thirdButton).getName());
                b_answer1.setText(list.get(forthButton).getName());

                break;
        }
    }
    /* This function creates the intent that will help send the score to the MainActivity2 */
    private void Send(){
        Intent intent = new Intent(guessing_animals.this,MainActivity2.class);
        intent.setType("text/plain");
        String previous_s2 = score.getText().toString();
        intent.putExtra("org.User.guessinggame.message",previous_s2);
        startActivity(intent);
    }
    /* creating a timer */
    private void startTimer(){
        mCountDownTimer = new CountDownTimer(mTimeLeftInMillis,1000) {
            @Override
            public void onTick(long l) {
                mTimeLeftInMillis = l;
                int seconds = (int)((mTimeLeftInMillis/1000)%60);
                String timeLeftFormatted = String.format("00:%02d",seconds);
                timer.setText(timeLeftFormatted);
                //Change the color of the timer indicating that the player is running out of time
                if (seconds < 11){
                    timer.setTextColor(Color.RED);
                }
                else{
                    timer.setTextColor(Color.BLACK);
                }
            }
            @Override
            public void onFinish() {
                mTimerRunning = false;
                finish();
            }
        }.start();
        mTimerRunning = true;
    }
    @Override
    protected void onSaveInstanceState(@NonNull Bundle outState) {
        super.onSaveInstanceState(outState);
        outState.putInt("key_current_score", current_score);
        outState.putLong("key_time", mTimeLeftInMillis);
    }

    @Override
    protected void onRestoreInstanceState(@NonNull Bundle savedInstanceState) {
        super.onRestoreInstanceState(savedInstanceState);
        current_score = savedInstanceState.getInt("key_current_score",0);
        mTimeLeftInMillis = savedInstanceState.getLong("key_time");
        score.setText(String.format("Score: %d", current_score));
    }
}