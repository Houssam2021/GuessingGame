package com.example.guessinggame;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class guessing_countries extends AppCompatActivity {
    private TextView score_c;
    private TextView timer_c;
    private TextView question_count;
    private TextView guess_country;

    private RadioGroup radio_grp;
    private RadioButton canada;
    private RadioButton china;
    private RadioButton brazil;
    private RadioButton algeria;
    private RadioButton russia;
    private RadioButton australia;

    private Button confirm_button;

    private List<Question> questionList;

    private int question_counter = 0; //number of the current question
    private int nbr_of_questions;
    private Question current_question;
    private int score;
    private boolean answered;

    private static final long COUNTDOWN_IN_MILLIS= 30000;
    private CountDownTimer mCountDownTimer;
    private boolean mTimerRunning; /* Tell us if the timer is running or not */
    private long mTimeLeftInMillis = COUNTDOWN_IN_MILLIS;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_guessing_countries);

        if(savedInstanceState != null){
            score = savedInstanceState.getInt("key_current_score",0);
            score_c.setText(String.format("Score: %d", score));
        }

        questionList = new ArrayList<>();

        score_c = findViewById(R.id.score_c);
        timer_c = findViewById(R.id.timer_c);
        question_count = findViewById(R.id.question_count);
        guess_country = findViewById(R.id.country);

        radio_grp = findViewById(R.id.radio_grp);
        canada = findViewById(R.id.canada);
        china = findViewById(R.id.china);
        brazil = findViewById(R.id.brazil);
        algeria = findViewById(R.id.algeria);
        australia = findViewById(R.id.australia);
        russia = findViewById(R.id.russia);

        confirm_button = findViewById(R.id.confirm_button);

        addQuestions();
        nbr_of_questions = questionList.size();
        startTimer();
    //  Collections.shuffle(questionList);
        nextQuestion();

        confirm_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
               if(!answered){
                   if(canada.isChecked() || russia.isChecked() ||australia.isChecked() ||algeria.isChecked() || china.isChecked() || brazil.isChecked()) {
                       checkAnswer();
                       Toast.makeText(guessing_countries.this, "CORRECT", Toast.LENGTH_SHORT).show();
                   }else{
                       Toast.makeText(guessing_countries.this, "Select an answer", Toast.LENGTH_SHORT).show();
                   }
               }else{
                   nextQuestion();
               }
            }
        });
    }

    private void addQuestions(){
        questionList.add(new Question("Brazil","A","B","C","D","E","F",2));
        questionList.add(new Question("Canada","A","B","C","D","E","F",1));
        questionList.add(new Question("Russia","A","B","C","D","E","F",4));
        questionList.add(new Question("Algeria","A","B","C","D","E","F",3));
        questionList.add(new Question("Australia","A","B","C","D","E","F",6));
        questionList.add(new Question("China","A","B","C","D","E","F",5));
    }

    private void checkAnswer(){
        answered = true;
        RadioButton rb_selected = findViewById(radio_grp.getCheckedRadioButtonId());
        int ans_nbr = radio_grp.indexOfChild(rb_selected) + 1;

        if (ans_nbr == current_question.getAnswerNbr()) {
            score++;
            score_c.setText(String.format("Score: %d", score));
        }else{
            if (score > 0) {
                score--;
            }
        }
        //checks if it's the last question.
        if (question_counter < nbr_of_questions) {
            confirm_button.setText("Next");
            //if it's not the last question, changes the confirm button to a "next" button
        }else{
            //when it's the last question, change confirm button to "finish" button
            confirm_button.setText("Finish");
            Send();
        }
    }
    private void nextQuestion() {
        //after each question we uncheck the radio button that was checked
        radio_grp.clearCheck();

        //checks if it's the last question.
        if (question_counter < nbr_of_questions){
            current_question = questionList.get(question_counter);
            guess_country.setText(current_question.getQuestion());

            //sets the options to the user:
            canada.setText(current_question.getCanada());
            brazil.setText(current_question.getBrazil());
            algeria.setText(current_question.getAlgeria());
            australia.setText(current_question.getAustralia());
            russia.setText(current_question.getRussia());
            china.setText(current_question.getChina());

            question_counter++;
            confirm_button.setText("Confirm");
            question_count.setText(String.format("Question: %d/%d", question_counter, nbr_of_questions));
            answered = false;
        }else{
            finish();
        }
    }

    private void startTimer(){
        mCountDownTimer = new CountDownTimer(mTimeLeftInMillis,1000) {
            @Override
            public void onTick(long l) {
                mTimeLeftInMillis = l;
                int seconds = (int)((mTimeLeftInMillis/1000)%60);
                String timeLeftFormatted = String.format("00:%02d",seconds);
                timer_c.setText(timeLeftFormatted);
                //Change the color of the timer indicating that the player is running out of time
                if (seconds < 11){
                    timer_c.setTextColor(Color.RED);
                }
                else{
                    timer_c.setTextColor(Color.BLACK);
                }
            }
            @Override
            public void onFinish() {
                mTimerRunning = false;
                finish();
            }
        }.start();
        mTimerRunning = true;
    }
    //sends final score to MainActivity2:
    private void Send(){
        Intent intent2 = new Intent(guessing_countries.this,MainActivity2.class);
        intent2.setType("text/plain");
        String previous_s2 = score_c.getText().toString();
        intent2.putExtra("org.User.guessinggame.message",previous_s2);
        startActivity(intent2);
    }
    @Override
    protected void onSaveInstanceState(@NonNull Bundle outState) {
        super.onSaveInstanceState(outState);
        outState.putInt("key_current_score", score);
    }

    @Override
    protected void onRestoreInstanceState(@NonNull Bundle savedInstanceState) {
        super.onRestoreInstanceState(savedInstanceState);
        score = savedInstanceState.getInt("key_current_score",0);
        score_c.setText(String.format("Score: %d", score));
    }
}