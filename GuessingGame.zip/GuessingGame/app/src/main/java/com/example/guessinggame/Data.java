package com.example.guessinggame;

public class Data {

    Integer[] animals = {
            R.drawable.bunny,
            R.drawable.deer,
            R.drawable.kingsnake,
            R.drawable.okapi,
            R.drawable.lemur,
            R.drawable.orangutang,
            R.drawable.red_panda,
            R.drawable.saiga_antelope,
            R.drawable.tucan,
            R.drawable.koala,
    };

    Integer[] answers = {
            R.string.bunny,
            R.string.deer,
            R.string.king_snake,
            R.string.okapi,
            R.string.lemur,
            R.string.orangatang,
            R.string.red_panda,
            R.string.saiga_antelope,
            R.string.toucan,
            R.string.koala,
    };
}
