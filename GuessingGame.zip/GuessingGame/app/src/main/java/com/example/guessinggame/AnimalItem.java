package com.example.guessinggame;

public class AnimalItem {
    int name;
    int image;

    public AnimalItem(int name, int image){
        this.name = name;
        this.image = image;
    }

    public int getName() {
        return name;
    }
    public int getImage() {
        return image;
    }
}
