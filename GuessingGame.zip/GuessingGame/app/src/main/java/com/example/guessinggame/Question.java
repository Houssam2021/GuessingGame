package com.example.guessinggame;

public class Question {
    private String question;
    private String canada;
    private String china;
    private String brazil;
    private String algeria;
    private String russia;
    private String australia;
    private int answerNbr;

    public Question(String question, String canada, String china, String brazil, String algeria, String russia, String australia, int answerNbr) {
        this.question = question;
        this.canada = canada;
        this.china = china;
        this.brazil = brazil;
        this.algeria = algeria;
        this.russia = russia;
        this.australia = australia;
        this.answerNbr = answerNbr;
    }

    public String getQuestion() {
        return question;
    }

    public void setQuestion(String question) {
        this.question = question;
    }

    public String getCanada() {
        return canada;
    }

    public void setCanada(String canada) {
        this.canada = canada;
    }

    public String getChina() {
        return china;
    }

    public void setChina(String china) {
        this.china = china;
    }

    public String getBrazil() {
        return brazil;
    }

    public void setBrazil(String brazil) {
        this.brazil = brazil;
    }

    public String getAlgeria() {
        return algeria;
    }

    public void setAlgeria(String algeria) {
        this.algeria = algeria;
    }

    public String getRussia() {
        return russia;
    }

    public void setRussia(String russia) {
        this.russia = russia;
    }

    public String getAustralia() {
        return australia;
    }

    public void setAustralia(String australia) {
        this.australia = australia;
    }

    public int getAnswerNbr() {
        return answerNbr;
    }

    public void setAnswerNbr(int answerNbr) {
        this.answerNbr = answerNbr;
    }
}
