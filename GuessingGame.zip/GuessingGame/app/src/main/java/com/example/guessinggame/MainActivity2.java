package com.example.guessinggame;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity2 extends AppCompatActivity {
    private Button mb_GuessCountry;
    private Button mb_GuessAnimal;
    private TextView mprev_score1;
    private TextView mprev_score2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        mb_GuessAnimal = findViewById(R.id.GuessAnimal);
        mb_GuessCountry = findViewById(R.id.GuessCountry);
        mprev_score1 = findViewById(R.id.prev_score1);
        mprev_score2 = findViewById(R.id.prev_score2);

        mb_GuessCountry.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity2.this,guessing_countries.class);
                startActivity(intent);
            }
        });
        Intent intent = getIntent();
        String previous_s1 = intent.getStringExtra("org.User.guessinggame.message");
        mprev_score1.setText(String.format("Previous %s", previous_s1));

        mb_GuessAnimal.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity2.this,guessing_animals.class);
                startActivity(intent);
            }
        });
        Intent intent2 = getIntent();
        String previous_s2 = intent2.getStringExtra("org.User.guessinggame.message");
        mprev_score2.setText(String.format("Previous %s", previous_s2));
    }
}